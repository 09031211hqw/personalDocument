#include "CCaliperGraphics.h"
#include "Generic.h"


CCaliperGraphics::CCaliperGraphics()
{
	m_pdCenter			= Point2d(0, 0);
	m_dRadius			= 0;
	m_dMeasureLength	= 0;
	m_dMeasureHeight	= 0;
	m_dSigma			= 1;
	m_nThreshold		= 30;
	m_nTranslation		= 1;
	m_nMeasureNums		= 0;
	m_eAdjustType		= AdjustType::None;
	m_pdSampleLineEnd	= Point2d(0, 0);
	m_nCircleSize		= 0;
	m_nSampleDirecion	= 0;
}

bool CCaliperGraphics::IsPointInCircle(Point2d pdCenter, Point2d pdPoint)
{
	return GetPPDistance(pdCenter, pdPoint) <= m_nCircleSize;
}


void CCaliperGraphics::CreateCaliper(Mat& InputMat, Point2d pdCenter, double dRadius, double dMeasureLength, double dMeasureHeight, 
	double dSigma, int nThreshold, int nTranslation, int nMesureNums, int nSampleDirection)
{
	if (InputMat.empty())
	{
		return;
	}
	InputMat.copyTo(m_mInputMat);
	m_pdCenter			= pdCenter;
	m_dRadius			= dRadius;
	m_dMeasureLength	= dMeasureLength;
	m_dMeasureHeight	= dMeasureHeight;
	m_dSigma			= dSigma;
	m_nThreshold		= nThreshold;
	m_nTranslation		= nTranslation;
	m_nMeasureNums		= nMesureNums;
	m_nCircleSize = InputMat.cols / 150;
	m_nSampleDirecion = nSampleDirection;
	//draw the expected circle.
	circle(InputMat, pdCenter, dRadius, Cyan);
	circle(InputMat, m_pdCenter, m_nCircleSize, Red, 1, 16);
	//Draw the equinox lines
	GetEquinoxPointsOfCircle(pdCenter, dRadius, m_nMeasureNums, m_vpdEquinoxPoints);
	RotatedRect rRect;
	double dAngle = 0;
	m_vdMeasureAngle.clear();
	Point2d pdStart, pdEnd;
	for (int i = 0; i < m_vpdEquinoxPoints.size(); i++)
	{
		if (m_nSampleDirecion == 1)
		{
			dAngle = GetAngleVecWithX(pdCenter, m_vpdEquinoxPoints[i]);
		}
		else if (m_nSampleDirecion == 0)
		{
			dAngle = GetAngleVecWithX(m_vpdEquinoxPoints[i], pdCenter);	
		}
		GetEndPointsOfLine(m_vpdEquinoxPoints[i], dAngle, m_dMeasureLength, pdStart, pdEnd);
		DrawArrow(InputMat, pdStart, pdEnd, m_nCircleSize * 5, Cyan);
		m_vdMeasureAngle.push_back(dAngle);
		rRect = RotatedRect(m_vpdEquinoxPoints[i], Size2f(dMeasureLength, dMeasureHeight), dAngle);
		DrawRectangle(InputMat, rRect, Blue, 1);
	}

	//Draws the sampling line direction
	dAngle = m_nSampleDirecion == 1 ? 0 : 180;
	int nIndex = 0;
	GetEndPointsOfLine(m_vpdEquinoxPoints[nIndex], dAngle, dMeasureLength, pdStart, m_pdSampleLineEnd);
	m_pdSampleLineCenter = m_vpdEquinoxPoints[nIndex];
	DrawArrow(InputMat, pdStart, m_pdSampleLineEnd, m_nCircleSize * 5, Cyan);
	circle(InputMat, m_pdSampleLineEnd, m_nCircleSize, Red, 1, 16);
}

void CCaliperGraphics::AdjustCaliper(Mat& InputMat, Point2d pdPoint, double dRadius, double dMeasureLength, double dMeasureHeight, double dSigma, int nThreshold, int nTranslation, int nMeasureNums, int nSampleDirecion, int nFlag)
{
	if (nFlag == 1)//drag move
	{
		m_eAdjustType = AdjustType::None;
		CreateCaliper(InputMat, m_pdCenter, m_dRadius, m_dMeasureLength, m_dMeasureHeight, m_dSigma, 
			m_nThreshold, m_nTranslation, m_nMeasureNums, m_nSampleDirecion);
		return;
	}
	if (IsPointInCircle(m_pdCenter, pdPoint))
	{
		m_eAdjustType = AdjustType::AdjustCenter;
	}
	else if(IsPointInCircle(m_pdSampleLineEnd,pdPoint))
	{
		m_eAdjustType = AdjustType::AdjustMeasureLength;
	}

	if (m_eAdjustType == AdjustType::AdjustCenter)
	{
		CreateCaliper(InputMat, pdPoint, m_dRadius, m_dMeasureLength, m_dMeasureHeight, m_dSigma, 
			m_nThreshold, m_nTranslation, m_nMeasureNums, m_nSampleDirecion);
	}
	else if (m_eAdjustType == AdjustType::AdjustMeasureLength)
	{
		double dMeasureLength = GetPPDistance(pdPoint, m_pdSampleLineCenter);
		//make sure the measure length would not be too long or too short. And the adjust circle is always in the expected circle.
		if (dMeasureLength >= m_dRadius - 2 * (double)m_nCircleSize || dMeasureLength < 1)
		{
			dMeasureLength = m_dMeasureLength;
		}
		else
		{
			dMeasureLength *= 2;
		}
		CreateCaliper(InputMat, m_pdCenter, m_dRadius, dMeasureLength, m_dMeasureHeight, m_dSigma, 
			m_nThreshold, m_nTranslation, m_nMeasureNums, m_nSampleDirecion);
	}
	else if (pdPoint.x == -1 && pdPoint.y == -1)
	{
		CreateCaliper(InputMat, m_pdCenter, m_dRadius, m_dMeasureLength, m_dMeasureHeight, m_dSigma, 
			m_nThreshold, m_nTranslation, nMeasureNums, m_nSampleDirecion);
	}
	else if (pdPoint.x == -2 && pdPoint.y == -2)
	{
		CreateCaliper(InputMat, m_pdCenter, m_dRadius, dMeasureLength, m_dMeasureHeight, m_dSigma, 
			m_nThreshold, m_nTranslation, m_nMeasureNums, m_nSampleDirecion);
	}
	else if (pdPoint.x == -3 && pdPoint.y == -3)
	{
		CreateCaliper(InputMat, m_pdCenter, m_dRadius, m_dMeasureLength, dMeasureHeight, m_dSigma, 
			m_nThreshold, m_nTranslation, m_nMeasureNums, m_nSampleDirecion);
	}
	else if (pdPoint.x == -4 && pdPoint.y == -4)//adjust the radius
	{
		CreateCaliper(InputMat, m_pdCenter, dRadius, m_dMeasureLength, m_dMeasureHeight, m_dSigma,
			m_nThreshold, m_nTranslation, m_nMeasureNums, m_nSampleDirecion);
	}
	else if (pdPoint.x == -5 && pdPoint.y == -5)//adjust the translation: 1, is the poistive; 0, is the negative
	{
		CreateCaliper(InputMat, m_pdCenter, m_dRadius, m_dMeasureLength, m_dMeasureHeight, m_dSigma,
			m_nThreshold, nTranslation, m_nMeasureNums, m_nSampleDirecion);
	}
	else if (pdPoint.x == -6 && pdPoint.y == -6)
	{
		CreateCaliper(InputMat, m_pdCenter, m_dRadius, m_dMeasureLength, m_dMeasureHeight, m_dSigma,
			m_nThreshold, m_nTranslation, m_nMeasureNums, nSampleDirecion);
	}
	else if (pdPoint.x == -7 && pdPoint.y == -7)//adjust sigma
	{
		CreateCaliper(InputMat, m_pdCenter, m_dRadius, m_dMeasureLength, m_dMeasureHeight, dSigma,
			m_nThreshold, m_nTranslation, m_nMeasureNums, m_nSampleDirecion);
	}
	else if (pdPoint.x == -8 && pdPoint.y == -8)//adjust threshold
	{
		CreateCaliper(InputMat, m_pdCenter, m_dRadius, m_dMeasureLength, m_dMeasureHeight, m_dSigma,
			nThreshold, m_nTranslation, m_nMeasureNums, m_nSampleDirecion);
	}
	else
	{
		CreateCaliper(InputMat, m_pdCenter, m_dRadius,m_dMeasureLength, m_dMeasureHeight, m_dSigma, 
			m_nThreshold, m_nTranslation, m_nMeasureNums, m_nSampleDirecion);
	}
}

void CCaliperGraphics::FitCircle(Point2d& pdCenter, double& dRadius, int nFitMethod)
{
	Mat RoiMat = Mat::zeros(m_mInputMat.size(), m_mInputMat.type());
	Mat mask = Mat::zeros(m_mInputMat.size(), CV_8U);
	circle(mask, m_pdCenter, m_dRadius + m_dMeasureLength * 0.5 + 10, Scalar(255), -1);
	m_mInputMat.copyTo(RoiMat, mask);
	//Extract 1D edge points
	m_vpdEdgePoints.clear();
	m_vdEdgeGradient.clear();
	vector<Point>temp;
	for (int i = 0; i < m_vpdEquinoxPoints.size(); i++)
	{
		vector<Edge1D_Result>edges = extract1DEdge.Get1DEdge(RoiMat, m_vpdEquinoxPoints[i], m_dMeasureLength, m_dMeasureHeight, m_vdMeasureAngle[i]
			, m_dSigma, m_nThreshold, m_nTranslation == 1 ? Translation::Poisitive : Translation::Negative, Selection::Strongest);
		for (int i = 0; i < edges.size(); i++)
		{
			m_vpdEdgePoints.push_back(edges[i].m_pdEdgePoint);
			m_vdEdgeGradient.push_back(edges[i].m_dGradient);
			temp.push_back(edges[i].m_pdEdgePoint);
		}
		//cout << edges[i].m_pdEdgePoint <<": " << edges[i].m_dGradient << endl;
	}
	if (m_vpdEdgePoints.size() == 0)
	{
		return;
	}
	RansacCircleFiler(m_vpdEdgePoints, m_vpdExcepetEdgePoints);
	for (Point2d point : m_vpdExcepetEdgePoints)//remove the excepted points.
	{
		for (int i = 0; i < m_vpdEdgePoints.size(); i++)
		{
			if (point == m_vpdEdgePoints[i])
			{
				m_vpdEdgePoints.erase(m_vpdEdgePoints.begin() + i);
				break;
			}
		}
	}
	if (nFitMethod == 0)
	{
		FitCircleWithLeastSquare(m_vpdEdgePoints, pdCenter, dRadius);
	}
	else if (nFitMethod == 1)
	{
		FitCircleWithHype(m_vpdEdgePoints, pdCenter, dRadius);
	}
	//else
	//{
	//	vector<Point2f>vpfEdgePoints(m_vpdEdgePoints.begin(), m_vpdEdgePoints.end());
	//	RotatedRect rRect = fitEllipse(vpfEdgePoints);
	//	pdCenter = rRect.center;
	//	dRadius = rRect.size.width*0.5;
	//}
	
}

void CCaliperGraphics::DisplayEdgePoints(Mat& InputMat, double dSize, Scalar color)
{
	if (InputMat.empty())
	{
		return;
	}
	for (auto edge : m_vpdEdgePoints)
	{
		DrawCross(InputMat, edge, 90, dSize, color, 1);
	}
	for (auto edge : m_vpdExcepetEdgePoints)
	{
		DrawCross(InputMat, edge, 90, dSize, Red, 1);
	}
}

void CCaliperGraphics::GetEdgeInfo(vector<Point2d>& vpdEdgePoints, vector<double>& vpdEdgePointsGradient)
{
	vpdEdgePoints = m_vpdEdgePoints;
	vpdEdgePointsGradient = m_vdEdgeGradient;
}

void CCaliperGraphics::FitCircleWithHype(vector<Point2d> pdPoints, Point2d& pdCenter, double& dRadius)
{
	int nSize = pdPoints.size();
	if (nSize < 3)
	{
		return;
	}
	vector<double>vdX;
	vector<double>vdY;
	double dMeanX = 0, dMeanY = 0;
	for (Point2d p : pdPoints)
	{
		vdX.push_back(p.x);
		vdY.push_back(p.y);
		dMeanX += p.x;
		dMeanY += p.y;
	}
	dMeanX /= (nSize * 1.);
	dMeanY /= (nSize * 1.);

	double Xi = 0, Yi = 0, Zi = 0;
	double Mz = 0, Mxy = 0, Mxx = 0, Myy = 0, Mxz = 0, Myz = 0, Mzz = 0, Cov_xy = 0, Var_z=0;
	double A0 = 0, A1 = 0, A2 = 0, A22 = 0;
	double Dy = 0, xnew = 0, x = 0, ynew = 0, y = 0;
	double DET = 0, Xcenter = 0, Ycenter = 0;
	for (int i = 0; i < nSize; i++)
	{
		Xi = vdX[i] - dMeanX;   //  centered x-coordinates
		Yi = vdY[i] - dMeanY;   //  centered y-coordinates
		Zi = Xi * Xi + Yi * Yi;

		Mxy += Xi * Yi;
		Mxx += Xi * Xi;
		Myy += Yi * Yi;
		Mxz += Xi * Zi;
		Myz += Yi * Zi;
		Mzz += Zi * Zi;
	}
	Mxx /= (nSize * 1.);
	Myy /= (nSize * 1.);
	Mxy /= (nSize * 1.);
	Mxz /= (nSize * 1.);
	Myz /= (nSize * 1.);
	Mzz /= (nSize * 1.);

	Mz = Mxx + Myy;
	Cov_xy = Mxx * Myy - Mxy * Mxy;
	Var_z = Mzz - Mz * Mz;

	A2 = 4.0 * Cov_xy - 3.0 * Mz * Mz - Mzz;
	A1 = Var_z * Mz + 4.0 * Cov_xy * Mz - Mxz * Mxz - Myz * Myz;
	A0 = Mxz * (Mxz * Myy - Myz * Mxy) + Myz * (Myz * Mxx - Mxz * Mxy) - Var_z * Cov_xy;
	A22 = A2 + A2;

	//    finding the root of the characteristic polynomial
//    using Newton's method starting at x=0  
//     (it is guaranteed to converge to the right root)
	x = 0., y = A0;
	for (int i = 0; i < 99; i++)  // usually, 4-6 iterations are enough
	{
		Dy = A1 + x * (A22 + 16. * x * x);
		xnew = x - y / Dy;
		if ((xnew == x) || (!isfinite(xnew)))
		{
			break;
		}
		ynew = A0 + xnew * (A1 + xnew * (A2 + 4.0 * xnew * xnew));
		if (abs(ynew) >= abs(y))
		{
			break;
		}
		x = xnew;  y = ynew;
	}

	DET = x * x - x * Mz + Cov_xy;
	Xcenter = (Mxz * (Myy - x) - Myz * Mxy) / DET / 2.0;
	Ycenter = (Myz * (Mxx - x) - Mxz * Mxy) / DET / 2.0;
	dRadius = sqrt(Xcenter * Xcenter + Ycenter * Ycenter + Mz - x - x);
	pdCenter = Point2d(Xcenter + dMeanX, Ycenter + dMeanY);

}

void CCaliperGraphics::FitCircleWithLeastSquare(vector<Point2d> pdPoints, Point2d& pdCenter, double& dRadius)
{
	int nSize = pdPoints.size();
	if (nSize < 3)
	{
		return;
	}
	double X1 = 0.0;
	double Y1 = 0.0;
	double X2 = 0.0;
	double Y2 = 0.0;
	double X3 = 0.0;
	double Y3 = 0.0;
	double X1Y1 = 0.0;
	double X1Y2 = 0.0;
	double X2Y1 = 0.0;
	for (Point2d p : pdPoints)
	{
		X1 = X1 + p.x;
		Y1 = Y1 + p.y;
		X2 = X2 + p.x * p.x;
		Y2 = Y2 + p.y * p.y;
		X3 = X3 + p.x * p.x * p.x;
		Y3 = Y3 + p.y * p.y * p.y;
		X1Y1 = X1Y1 + p.x * p.y;
		X1Y2 = X1Y2 + p.x * p.y * p.y;
		X2Y1 = X2Y1 + p.x * p.x * p.y;
	}
	double C = 0.0;
	double D = 0.0;
	double E = 0.0;
	double G = 0.0;
	double H = 0.0;
	double a = 0.0;
	double b = 0.0;
	double c = 0.0;
	C = nSize * X2 - X1 * X1;
	D = nSize * X1Y1 - X1 * Y1;
	E = nSize * X3 + nSize * X1Y2 - (X2 + Y2) * X1;
	G = nSize * Y2 - Y1 * Y1;
	H = nSize * X2Y1 + nSize * Y3 - (X2 + Y2) * Y1;
	a = (H * D - E * G) / (C * G - D * D);
	b = (H * C - E * D) / (D * D - G * C);
	c = -(a * X1 + b * Y1 + X2 + Y2) / nSize;
	double A = 0.0;
	double B = 0.0;
	double R = 0.0;
	A = a / (-2);
	B = b / (-2);
	R = double(sqrt(a * a + b * b - 4 * c) / 2);
	pdCenter.x = A;
	pdCenter.y = B;
	dRadius = R;
}

void CCaliperGraphics::RansacCircleFiler(const vector<Point2d>& points, vector<Point2d>& vpdExceptPoints, double sigma)
{
	unsigned int n = points.size();

	if (n < 3)
	{
		return;
	}

	RNG random;
	double bestScore = -1.;
	vector<Point2d>vpdTemp;
	int iterations = log(1 - 0.99) / (log(1 - (1.00 / n)));

	for (int k = 0; k < iterations; k++)
	{
		int i1 = 0, i2 = 0, i3 = 0;
		Point2d p1(0, 0), p2(0, 0), p3(0, 0);
		while (true)
		{
			i1 = random(n);
			i2 = random(n);
			i3 = random(n);
			if ((i1 != i2 && i1 != i3 && i2 != i3))
			{
				if ((points[i1].y != points[i2].y) && (points[i1].y != points[i3].y))
				{
					break;
				}
			}
		}
		p1 = points[i1];
		p2 = points[i2];
		p3 = points[i3];

		//use three points to caculate a circle
		Point2d pdP12 = GetPPCenter(p1, p2);
		double dK1 = -1 / GetLineSlope(p1, p2);
		double dB1 = pdP12.y - dK1 * pdP12.x;
		Point2d pdP13 = GetPPCenter(p1, p3);
		double dK2 = -1 / GetLineSlope(p1, p3);
		double dB2 = pdP13.y - dK2 * pdP13.x;
		Point2d pdCenter(0, 0);
		pdCenter.x = (dB2 - dB1) / (dK1 - dK2);
		pdCenter.y = dK1 * pdCenter.x + dB1;
		double dR = GetPPDistance(pdCenter, p1);
		double score = 0;
		vpdTemp.clear();
		for (int i = 0; i < n; i++)
		{
			double d = dR - GetPPDistance(points[i], pdCenter);
			if (fabs(d) < sigma)
			{
				score += 1;
			}
			else
			{
				vpdTemp.push_back(points[i]);
			}
		}
		if (score > bestScore)
		{
			bestScore = score;
			vpdExceptPoints = vpdTemp;
		}
	}
}