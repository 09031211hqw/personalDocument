﻿// 1DEdgeExtraction.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//
#include "stdlib.h"
#include<opencv2/opencv.hpp>
#include <iostream>
#include <vector>
#include "Generic.h"
#include "CCaliperGraphics.h"
using namespace std;
using namespace cv;


string WindowHandle = to_string(0);
string WindowHandle2 = to_string(1);

Mat srcImage;
Mat dstImage;

int nSampleDirection = 0;
int nMeasureNums = 20;
int nMeasureHeight = 10;
int nMeasureLength = 100;
int nSigma = 1;
int nThreshold = 30;
int nTranslation = 0;
int nFitCircle = 0;
int nRadius = 250;

//double dLength = 0;
//double dHeight = 100;
//double dAngle = 0;
//Point2d centerPoint(0, 0);
//RotatedRect rotateRect;
//Point2f RectPoints[4];
CCaliperGraphics caliperGraphics;
void InitializeWindow(Mat& matImage, string szWindowHandle, int nWindowRatio = 1)
{
    if (matImage.empty() == true || nWindowRatio == 0)
    {
        return;
    }
    int nImageWidth = matImage.size().width;
    int nImageHeight = matImage.size().height;
    namedWindow(szWindowHandle, WINDOW_KEEPRATIO);
    resizeWindow(szWindowHandle, nImageWidth / nWindowRatio, nImageHeight / nWindowRatio);
}

void On_Mouse(int event, int x, int y, int flags, void* ustc)
{
    if (event == EVENT_MOUSEMOVE && (flags & EVENT_FLAG_LBUTTON))
    {
        dstImage.copyTo(srcImage);
        caliperGraphics.AdjustCaliper(srcImage, Point2d(x, y), nRadius, nMeasureLength, nMeasureHeight,
            1, nThreshold, nTranslation, nMeasureNums, nSampleDirection);
        imshow(WindowHandle, srcImage);
    }
    else if (event == EVENT_LBUTTONUP)
    {
        dstImage.copyTo(srcImage);
        caliperGraphics.AdjustCaliper(srcImage, Point2d(x, y), nRadius, nMeasureLength, nMeasureHeight,
            1, nThreshold, nTranslation, nMeasureNums, nSampleDirection, 1);
        imshow(WindowHandle, srcImage);
    }
}

void On_AdjustMeasureNums(int, void*)
{
    dstImage.copyTo(srcImage);
    caliperGraphics.AdjustCaliper(srcImage, Point2d(-1, -1), nRadius, nMeasureLength, nMeasureHeight,
        1, nThreshold, nTranslation, nMeasureNums, nSampleDirection);
    imshow(WindowHandle, srcImage);
}

void On_AdjustMeasureHeight(int, void*)
{
    dstImage.copyTo(srcImage);
    caliperGraphics.AdjustCaliper(srcImage, Point2d(-3, -3), nRadius, nMeasureLength, nMeasureHeight, 
        1, nThreshold, nTranslation, nMeasureNums, nSampleDirection);
    imshow(WindowHandle, srcImage);
}

void On_AdjustMeasureLength(int, void*)
{
    dstImage.copyTo(srcImage);
    caliperGraphics.AdjustCaliper(srcImage, Point2d(-2, -2), nRadius, nMeasureLength, nMeasureHeight, 
        1, nThreshold, nTranslation, nMeasureNums, nSampleDirection);
    imshow(WindowHandle, srcImage);
}

void On_SetTranslation(int, void*)
{
    dstImage.copyTo(srcImage);
    caliperGraphics.AdjustCaliper(srcImage, Point2d(-5, -5), nRadius, nMeasureLength, nMeasureHeight, 
        1, nThreshold, nTranslation, nMeasureNums, nSampleDirection);
    imshow(WindowHandle, srcImage);
}

void On_SetRadius(int, void*)
{
    dstImage.copyTo(srcImage);
    caliperGraphics.AdjustCaliper(srcImage, Point2d(-4, -4), nRadius, nMeasureLength, nMeasureHeight,
        1, nThreshold, nTranslation, nMeasureNums, nSampleDirection);
    imshow(WindowHandle, srcImage);
}

void On_SetSigma(int, void*)
{
    dstImage.copyTo(srcImage);
    caliperGraphics.AdjustCaliper(srcImage, Point2d(-7, -7), nRadius, nMeasureLength, nMeasureHeight,
        nSigma, nThreshold, nTranslation, nMeasureNums, nSampleDirection);
    imshow(WindowHandle, srcImage);
}

void On_SetThreshold(int, void*)
{
    dstImage.copyTo(srcImage);
    caliperGraphics.AdjustCaliper(srcImage, Point2d(-8, -8), nRadius, nMeasureLength, nMeasureHeight,
        1, nThreshold, nTranslation, nMeasureNums, nSampleDirection);
    imshow(WindowHandle, srcImage);
}

void On_SetSampleDirection(int, void*)
{
    dstImage.copyTo(srcImage);
    caliperGraphics.AdjustCaliper(srcImage, Point2d(-6, -6), nRadius, nMeasureLength, nMeasureHeight,
        1, nThreshold, nTranslation, nMeasureNums, nSampleDirection);
    imshow(WindowHandle, srcImage);
}


void On_FitCircle(int, void*)
{
    if (nFitCircle == 1)
    {
        Point2d pdCenter(0, 0);
        double dRadius = 0;
        caliperGraphics.FitCircle(pdCenter, dRadius, 1);
        dstImage.copyTo(srcImage);

        //Draw edge points
        caliperGraphics.DisplayEdgePoints(srcImage, 10, Green);
        //Draw fit circle
        circle(srcImage, pdCenter, dRadius, Green);
        DrawCross(srcImage, pdCenter, 90, 5, Green);
        imshow(WindowHandle, srcImage);
        cout << "Circle info: " << pdCenter << ", Radius: " << dRadius <<endl;
        //print edge point info
        vector<Point2d>vpdEdgePoints;
        vector<double>vdEdgePointsGradient;
        caliperGraphics.GetEdgeInfo(vpdEdgePoints, vdEdgePointsGradient);
        for (int i = 0; i < vpdEdgePoints.size(); i++)
        {
            cout << "Edge Point[" << i << "]: " << vpdEdgePoints[i] << ", gradient: " << vdEdgePointsGradient[i] << endl;
        }
    }

}

void InitializeMeasureTrackbar()
{
    namedWindow("Track", WINDOW_KEEPRATIO);
    resizeWindow("Track", Size(500, 250));

    createTrackbar("Nums", "Track", &nMeasureNums, 99, On_AdjustMeasureNums);
    setTrackbarMin("Nums", "Track", 3);

    createTrackbar("Radius", "Track", &nRadius, 1000, On_SetRadius);

    createTrackbar("Length", "Track", &nMeasureLength, 500, On_AdjustMeasureLength);
    setTrackbarMin("Length", "Track", 1);

    createTrackbar("Height", "Track", &nMeasureHeight, 500, On_AdjustMeasureHeight);
    setTrackbarMin("Height", "Track", 5);

    createTrackbar("SampleDirec", "Track", &nSampleDirection, 1, On_SetSampleDirection);

    createTrackbar("Trans", "Track", &nTranslation, 1, On_SetTranslation);

    createTrackbar("Threshold", "Track", &nThreshold, 255, On_SetThreshold);
    setTrackbarMin("Threshold", "Track", 1);

    createTrackbar("Sigma", "Track", &nSigma, 99, On_SetSigma);
    setTrackbarMin("Sigma", "Track", 1);

    createTrackbar("FitCircle", "Track", &nFitCircle, 1, On_FitCircle);

}

int main()
{
    srcImage = imread(".\\image\\circular_barcode.png");
    //srcImage = imread(".\\image\\halogen_bulb_01.png");
    //srcImage = imread(".\\image\\clamp_sloped_01.png");
    //srcImage = imread(".\\image\\dip_switch_02.png");
    //srcImage = imread(".\\image\\fuse.png");
    //srcImage = imread(".\\image\\metal-part-distorted-02.png");
    if (srcImage.empty())
    {
        cout << "fail to load the image, please check the image's path whether is correct." << endl;
        system("pause");
        return 0;
    }
    srcImage.copyTo(dstImage);
    InitializeWindow(srcImage, WindowHandle, 1);
    setMouseCallback(WindowHandle, On_Mouse, 0);
    caliperGraphics.CreateCaliper(srcImage, Point2d(srcImage.size().width / 2, srcImage.size().height / 2), nRadius, nMeasureLength,
        nMeasureHeight, 1, 30, nTranslation, nMeasureNums, nSampleDirection);
    InitializeMeasureTrackbar();
   
    waitKey(0);

}


