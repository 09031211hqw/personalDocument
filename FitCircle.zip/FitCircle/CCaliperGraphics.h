#include<opencv2/opencv.hpp>
#include <iostream>
#include <vector>
#include <list>
#include "Extract1DEdge.h"
using namespace std;
using namespace cv;
#pragma once
class CCaliperGraphics
{
protected:
	enum class AdjustType
	{
		None = 0,
		AdjustCenter,
		AdjustRadius,
		AdjustMeasureLength,
		AdjustMeasureHeight,
		AdjustMeasureNums,
	};
	Mat		m_mInputMat;
	Point2d m_pdCenter;
	double	m_dRadius;
	double	m_dMeasureLength;
	double	m_dMeasureHeight;
	double	m_dSigma;
	int		m_nThreshold;
	int		m_nTranslation;
	int		m_nMeasureNums;
	int		m_nSampleDirecion;//1: from center to outer;0: from outer to center.
	vector<Point2d>m_vpdEquinoxPoints;
	vector<double>m_vdMeasureAngle;
	vector<Point2d>m_vpdEdgePoints;
	vector<Point2d>m_vpdExcepetEdgePoints;
	vector<double>m_vdEdgeGradient;

	Point2d m_pdSampleLineEnd;
	Point2d m_pdSampleLineCenter;

	AdjustType m_eAdjustType;
private:
	bool IsPointInCircle(Point2d pdCenter, Point2d pdPoint);
	int m_nCircleSize = 0;
	Extract1DEdge	extract1DEdge;
	void FitCircleWithHype(vector<Point2d>pdPoints, Point2d& pdCenter, double& dRadius);
	void FitCircleWithLeastSquare(vector<Point2d>pdPoints, Point2d& pdCenter, double& dRadius);
	void RansacCircleFiler(const vector<Point2d>& points, vector<Point2d>& vpdExceptPoints, double sigma = 10);
public:
	CCaliperGraphics();
	void CreateCaliper(Mat& InputMat, Point2d pdCenter, double dRadius, double dMeasureLength, double dMeasureHeight, double dSigma, int nThreshold, int nTranslation, int nMesureNums, int nSampleDirection);
	void AdjustCaliper(Mat& InputMat, Point2d pdPoint, double dRadius, double dMeasureLength, double dMeasureHeight, double dSigma, int nThreshold, int nTranslation, int nMeasureNums, int nSampleDirection, int nFlag = 0);
	void FitCircle(Point2d& pdCenter, double& dRadius, int nFitMethod = 0);
	void DisplayEdgePoints(Mat& InputMat, double dSize, Scalar color);
	void GetEdgeInfo(vector<Point2d>& vpdEdgePoints, vector<double>& vpdEdgePointsGradient);
};

